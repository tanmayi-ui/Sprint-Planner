import React, { useState, useEffect, useRef } from 'react';
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

// ─── Constants ────────────────────────────────────────────────────────────────

const STATUS_CONFIG = {
  backlog:       { label: 'Backlog',      color: '#94a3b8', bg: 'rgba(148,163,184,0.12)' },
  todo:          { label: 'To do',        color: '#f59e0b', bg: 'rgba(245,158,11,0.12)'  },
  'in-progress': { label: 'In progress',  color: '#3b82f6', bg: 'rgba(59,130,246,0.12)'  },
  review:        { label: 'Review',       color: '#8b5cf6', bg: 'rgba(139,92,246,0.12)'  },
  blocked:       { label: 'Blocked',      color: '#ef4444', bg: 'rgba(239,68,68,0.12)'   },
  done:          { label: 'Done',         color: '#10b981', bg: 'rgba(16,185,129,0.12)'  },
};
const STATUS_ORDER = Object.keys(STATUS_CONFIG);

const PRIORITY_CONFIG = {
  high:   { color: '#ef4444' },
  medium: { color: '#f59e0b' },
  low:    { color: '#94a3b8' },
};

// ─── Shared helpers ───────────────────────────────────────────────────────────

function extractId(url) {
  return url.match(/\/d\/([a-zA-Z0-9-_]+)/)?.[1];
}

function normalize(str) {
  return (str || '').toLowerCase().trim();
}

function initials(name) {
  if (!name) return '?';
  return name.trim().split(/\s+/).map(w => w[0]?.toUpperCase() || '').slice(0, 2).join('');
}

function mapRow(row, headers, i) {
  const obj = { id: i, status: 'backlog', priority: 'medium', sprint: 1 };
  headers.forEach((h, idx) => {
    const key = normalize(h);
    const val = row[idx] || '';
    if      (key.includes('project'))                                   obj.project     = val;
    else if (key.includes('task') || key === 'name' || key === 'title') obj.task        = val;
    else if (key.includes('desc'))                                       obj.description = val;
    else if (key.includes('owner') || key.includes('assign'))           obj.owner       = val;
    else if (key.includes('status'))   obj.status   = normalize(val).replace(/\s+/g, '-') || 'backlog';
    else if (key.includes('priority')) obj.priority = normalize(val) || 'medium';
    else if (key.includes('due') || key.includes('date')) obj.dueDate = val;
    else if (key.includes('tag')  || key.includes('label')) obj.tags  = val;
    else if (key.includes('sprint')) obj.sprint = parseInt(val) || 1;
  });
  if (!obj.task) obj.task = obj.project || `Task ${i + 1}`;
  return obj;
}

// ─── Date helpers ─────────────────────────────────────────────────────────────

const TODAY = new Date();

function getMonday(d) {
  const dt  = new Date(d);
  const day = dt.getDay();
  dt.setDate(dt.getDate() + (day === 0 ? -6 : 1 - day));
  dt.setHours(0, 0, 0, 0);
  return dt;
}

function addDays(d, n) {
  const dt = new Date(d);
  dt.setDate(dt.getDate() + n);
  return dt;
}

function fmtShort(d) {
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

function weekRangeLabel(monday) {
  return `${fmtShort(monday)} – ${fmtShort(addDays(monday, 6))}`;
}

function isoWeekKey(d) {
  return getMonday(d).toISOString().slice(0, 10);
}

// ─── Google Sheets write-back (Apps Script backend) ───────────────────────────
// To enable write-back, deploy this Apps Script as a Web App (Execute as: Me, Anyone):
//
// function doPost(e) {
//   const { action, sheetId, sheetName, rowIndex, data } = JSON.parse(e.postData.contents);
//   const ss   = SpreadsheetApp.openById(sheetId);
//   const sheet = ss.getSheetByName(sheetName);
//   if (action === 'update') {
//     const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
//     const row = rowIndex + 2; // +1 header, +1 1-indexed
//     headers.forEach((h, i) => {
//       if (data[h.toLowerCase()] !== undefined)
//         sheet.getRange(row, i + 1).setValue(data[h.toLowerCase()]);
//     });
//   } else if (action === 'append') {
//     const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
//     sheet.appendRow(headers.map(h => data[h.toLowerCase()] || ''));
//   }
//   return ContentService.createTextOutput('ok');
// }
//
// Then set APPS_SCRIPT_URL below to your deployed Web App URL.

const APPS_SCRIPT_URL = ''; // e.g. 'https://script.google.com/macros/s/YOUR_ID/exec'

async function writeToSheet(action, sheetId, sheetName, rowIndex, data) {
  if (!APPS_SCRIPT_URL) return { ok: false, reason: 'No Apps Script URL configured' };
  try {
    const res = await fetch(APPS_SCRIPT_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, sheetId, sheetName, rowIndex, data }),
    });
    return { ok: res.ok };
  } catch (e) {
    return { ok: false, reason: e.message };
  }
}

// ─── Sample data ──────────────────────────────────────────────────────────────

const SAMPLE_DATA = [
  { id:0,  sprint:1, project:'Website Redesign', task:'Wireframe homepage',    description:'Create lo-fi wireframes for hero section', owner:'Alex M',   status:'done',        priority:'high',   dueDate:'2025-04-05' },
  { id:1,  sprint:1, project:'Website Redesign', task:'Design system tokens',  description:'Set up color, type & spacing tokens',      owner:'Priya S',  status:'in-progress', priority:'high',   dueDate:'2025-04-12' },
  { id:2,  sprint:1, project:'Website Redesign', task:'Component library',     description:'Build reusable React components',          owner:'Priya S',  status:'todo',        priority:'medium', dueDate:'2025-04-20' },
  { id:3,  sprint:1, project:'Website Redesign', task:'SEO audit',             description:'Audit and fix meta tags',                  owner:'Jordan K', status:'backlog',     priority:'low',    dueDate:''           },
  { id:4,  sprint:2, project:'Mobile App',       task:'Auth flow',             description:'Implement login & signup screens',         owner:'Alex M',   status:'review',      priority:'high',   dueDate:'2025-04-08' },
  { id:5,  sprint:2, project:'Mobile App',       task:'Push notifications',    description:'Integrate FCM for alerts',                 owner:'Sam T',    status:'blocked',     priority:'medium', dueDate:'2025-04-15' },
  { id:6,  sprint:2, project:'Mobile App',       task:'Offline sync',          description:'Cache data for offline use',               owner:'Sam T',    status:'done',        priority:'low',    dueDate:''           },
  { id:7,  sprint:2, project:'Data Pipeline',    task:'ETL job setup',         description:'Configure nightly data ingestion',         owner:'Jordan K', status:'done',        priority:'high',   dueDate:'2025-04-01' },
  { id:8,  sprint:3, project:'Data Pipeline',    task:'Dashboard charts',      description:'Build Recharts visualizations',            owner:'Priya S',  status:'in-progress', priority:'medium', dueDate:'2025-04-18' },
  { id:9,  sprint:3, project:'Data Pipeline',    task:'Alerting rules',        description:'Set up anomaly detection alerts',          owner:'Jordan K', status:'todo',        priority:'medium', dueDate:'2025-04-22' },
  { id:10, sprint:3, project:'Mobile App',       task:'Dark mode',             description:'Implement dark mode toggle',               owner:'Priya S',  status:'backlog',     priority:'low',    dueDate:''           },
];

// ─── Shared UI atoms ──────────────────────────────────────────────────────────

function Avatar({ name, size = 22 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      background: '#dbeafe', color: '#1d4ed8',
      fontSize: size * 0.45, fontWeight: 500,
      display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
    }}>
      {initials(name)}
    </div>
  );
}

function StatusPill({ status }) {
  const c = STATUS_CONFIG[status] || STATUS_CONFIG.backlog;
  return (
    <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 999, fontWeight: 500, background: c.bg, color: c.color }}>
      {c.label}
    </span>
  );
}

function PriorityDot({ priority }) {
  const c = PRIORITY_CONFIG[priority] || PRIORITY_CONFIG.medium;
  return <span style={{ width: 7, height: 7, borderRadius: '50%', background: c.color, display: 'inline-block', flexShrink: 0 }} />;
}

const moveBtnStyle = {
  padding: '2px 8px', fontSize: 11,
  border: '0.5px solid #e2e8f0', background: '#f8fafc',
  color: '#64748b', borderRadius: 4, cursor: 'pointer',
};

const btnBase = {
  padding: '6px 14px', fontSize: 13, borderRadius: 8, cursor: 'pointer',
  border: '0.5px solid #e2e8f0', background: '#fff', color: '#0f172a',
};

// ─── New Task Modal ───────────────────────────────────────────────────────────

function NewTaskModal({ onClose, onSave, projectOptions, ownerOptions, currentSprint }) {
  const [form, setForm] = useState({
    task: '', project: projectOptions[0] || '', description: '',
    owner: ownerOptions[0] || '', status: 'todo', priority: 'medium',
    dueDate: '', sprint: currentSprint,
  });
  const [saving, setSaving] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    if (!form.task.trim()) return;
    setSaving(true);
    await onSave(form);
    setSaving(false);
    onClose();
  };

  const inputStyle = {
    width: '100%', padding: '7px 10px', fontSize: 13, borderRadius: 8,
    border: '0.5px solid #e2e8f0', background: '#f8fafc', color: '#0f172a',
    boxSizing: 'border-box',
  };
  const labelStyle = { fontSize: 12, color: '#64748b', marginBottom: 4, display: 'block' };

  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.3)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100,
    }}>
      <div style={{
        background: '#fff', borderRadius: 14, padding: 24, width: 480, maxWidth: '95vw',
        border: '0.5px solid #e2e8f0', boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
          <span style={{ fontSize: 16, fontWeight: 500, color: '#0f172a' }}>New task</span>
          <button onClick={onClose} style={{ ...btnBase, padding: '3px 10px', fontSize: 18, color: '#94a3b8' }}>×</button>
        </div>

        <div style={{ display: 'grid', gap: 14 }}>
          <div>
            <label style={labelStyle}>Task name *</label>
            <input style={inputStyle} value={form.task} onChange={e => set('task', e.target.value)} placeholder="Enter task name…" autoFocus />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div>
              <label style={labelStyle}>Project</label>
              <input style={inputStyle} value={form.project} onChange={e => set('project', e.target.value)}
                list="project-list" placeholder="Project name" />
              <datalist id="project-list">{projectOptions.map(p => <option key={p} value={p} />)}</datalist>
            </div>
            <div>
              <label style={labelStyle}>Owner</label>
              <input style={inputStyle} value={form.owner} onChange={e => set('owner', e.target.value)}
                list="owner-list" placeholder="Owner name" />
              <datalist id="owner-list">{ownerOptions.map(o => <option key={o} value={o} />)}</datalist>
            </div>
          </div>
          <div>
            <label style={labelStyle}>Description</label>
            <textarea style={{ ...inputStyle, resize: 'vertical', minHeight: 64 }}
              value={form.description} onChange={e => set('description', e.target.value)} placeholder="Optional description…" />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 12 }}>
            <div>
              <label style={labelStyle}>Status</label>
              <select style={inputStyle} value={form.status} onChange={e => set('status', e.target.value)}>
                {STATUS_ORDER.map(s => <option key={s} value={s}>{STATUS_CONFIG[s].label}</option>)}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Priority</label>
              <select style={inputStyle} value={form.priority} onChange={e => set('priority', e.target.value)}>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>
            <div>
              <label style={labelStyle}>Sprint</label>
              <input style={inputStyle} type="number" min="1" value={form.sprint} onChange={e => set('sprint', parseInt(e.target.value) || 1)} />
            </div>
            <div>
              <label style={labelStyle}>Due date</label>
              <input style={inputStyle} type="date" value={form.dueDate} onChange={e => set('dueDate', e.target.value)} />
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 20 }}>
          <button style={btnBase} onClick={onClose}>Cancel</button>
          <button
            style={{ ...btnBase, background: '#0f172a', color: '#fff', border: 'none', opacity: saving ? 0.6 : 1 }}
            onClick={handleSave} disabled={saving || !form.task.trim()}
          >
            {saving ? 'Saving…' : 'Add task'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Board view ───────────────────────────────────────────────────────────────

function BoardView({ tasks, onMove }) {
  const [expandedDone, setExpandedDone] = useState({});

  const byStatus = {};
  STATUS_ORDER.forEach(s => (byStatus[s] = []));
  tasks.forEach(p => {
    const s = STATUS_ORDER.includes(p.status) ? p.status : 'backlog';
    byStatus[s].push(p);
  });

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, minmax(0,1fr))', gap: 12 }}>
      {STATUS_ORDER.map(status => {
        const allItems   = byStatus[status];
        const isDone     = status === 'done';
        const expanded   = expandedDone[status];
        const visibleItems = isDone && !expanded ? [] : allItems;
        const c = STATUS_CONFIG[status];

        return (
          <div key={status} style={{ background: '#f8fafc', borderRadius: 12, padding: 12, border: '0.5px solid #e2e8f0' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: c.color, display: 'inline-block' }} />
                <span style={{ fontSize: 13, fontWeight: 500, color: c.color }}>{c.label}</span>
              </div>
              <span style={{ fontSize: 11, padding: '2px 7px', borderRadius: 999, background: '#fff', color: '#64748b', border: '0.5px solid #e2e8f0' }}>
                {allItems.length}
              </span>
            </div>

            {visibleItems.map(p => (
              <div key={p.id} style={{ background: '#fff', border: '0.5px solid #e2e8f0', borderRadius: 8, padding: 10, marginBottom: 8 }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 4, marginBottom: 2 }}>
                  <span style={{ fontSize: 13, fontWeight: 500, color: '#0f172a' }}>{p.task}</span>
                  <PriorityDot priority={p.priority} />
                </div>
                {p.project     && <div style={{ fontSize: 11, color: '#64748b', marginBottom: 3 }}>{p.project}</div>}
                {p.description && <div style={{ fontSize: 11, color: '#94a3b8', marginBottom: 6, lineHeight: 1.5 }}>{p.description}</div>}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: '#64748b' }}>
                    <Avatar name={p.owner} size={20} />{p.owner || '—'}
                  </div>
                  {p.dueDate && <span style={{ fontSize: 11, color: '#94a3b8' }}>{p.dueDate}</span>}
                </div>
                {!isDone && (
                  <div style={{ display: 'flex', gap: 4, marginTop: 6 }}>
                    <button onClick={() => onMove(p.id, -1)} style={moveBtnStyle}>← Back</button>
                    <button onClick={() => onMove(p.id,  1)} style={moveBtnStyle}>Forward →</button>
                  </div>
                )}
              </div>
            ))}

            {isDone && allItems.length > 0 && (
              <button
                onClick={() => setExpandedDone(e => ({ ...e, [status]: !e[status] }))}
                style={{ width: '100%', padding: '6px', fontSize: 12, cursor: 'pointer',
                  border: '0.5px dashed #cbd5e1', borderRadius: 8, background: 'transparent',
                  color: '#94a3b8', marginTop: 4 }}
              >
                {expanded ? `▲ Hide ${allItems.length} done` : `▼ Show ${allItems.length} done`}
              </button>
            )}

            {!isDone && allItems.length === 0 && (
              <div style={{ fontSize: 12, color: '#cbd5e1', textAlign: 'center', padding: '16px 0' }}>Empty</div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── List view ────────────────────────────────────────────────────────────────

function ListView({ tasks }) {
  const [showDone, setShowDone] = useState(false);
  const doneTasks    = tasks.filter(t => t.status === 'done');
  const nonDoneTasks = tasks.filter(t => t.status !== 'done');
  const visibleTasks = showDone ? tasks : nonDoneTasks;

  const col  = (flex) => ({ flex, fontSize: 13, color: '#0f172a' });
  const head = (flex) => ({ flex, fontSize: 12, color: '#64748b', fontWeight: 500 });

  return (
    <div style={{ background: '#fff', border: '0.5px solid #e2e8f0', borderRadius: 12, overflow: 'hidden' }}>
      <div style={{ display: 'flex', alignItems: 'center', padding: '8px 12px', background: '#f8fafc', borderBottom: '0.5px solid #e2e8f0' }}>
        <span style={head(2)}>Task</span>
        <span style={head(1.5)}>Project</span>
        <span style={head(1)}>Owner</span>
        <span style={head(1)}>Status</span>
        <span style={head(0.5)}>Sprint</span>
        <span style={{ ...head(0.6), textAlign: 'right' }}>Due</span>
      </div>

      {visibleTasks.length === 0 && <div style={{ textAlign: 'center', padding: 40, color: '#94a3b8' }}>No tasks match filters</div>}

      {visibleTasks.map(p => (
        <div key={p.id} style={{ display: 'flex', alignItems: 'center', padding: '8px 12px', borderBottom: '0.5px solid #f1f5f9',
          opacity: p.status === 'done' ? 0.6 : 1 }}>
          <span style={{ ...col(2), display: 'flex', alignItems: 'center', gap: 6 }}>
            <PriorityDot priority={p.priority} />{p.task}
          </span>
          <span style={{ ...col(1.5), color: '#64748b', fontSize: 12 }}>{p.project || '—'}</span>
          <span style={{ ...col(1), display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, color: '#64748b' }}>
            <Avatar name={p.owner} size={18} />{p.owner || '—'}
          </span>
          <span style={col(1)}><StatusPill status={p.status} /></span>
          <span style={{ ...col(0.5), fontSize: 12, color: '#94a3b8' }}>S{p.sprint || 1}</span>
          <span style={{ flex: 0.6, textAlign: 'right', fontSize: 12, color: '#94a3b8' }}>{p.dueDate || '—'}</span>
        </div>
      ))}

      {doneTasks.length > 0 && (
        <div
          onClick={() => setShowDone(s => !s)}
          style={{ padding: '10px 12px', cursor: 'pointer', fontSize: 12, color: '#94a3b8',
            background: '#f8fafc', borderTop: '0.5px solid #e2e8f0', textAlign: 'center' }}
        >
          {showDone ? `▲ Hide ${doneTasks.length} completed tasks` : `▼ Show ${doneTasks.length} completed tasks`}
        </div>
      )}
    </div>
  );
}

// ─── Summary view ─────────────────────────────────────────────────────────────

function SummaryView({ tasks }) {
  const total   = tasks.length;
  const done    = tasks.filter(t => t.status === 'done').length;
  const blocked = tasks.filter(t => t.status === 'blocked').length;
  const inProg  = tasks.filter(t => t.status === 'in-progress').length;
  const pct     = total > 0 ? Math.round((done / total) * 100) : 0;

  const grouped = tasks.reduce((acc, p) => {
    const key = p.project || 'Uncategorized';
    if (!acc[key]) acc[key] = [];
    acc[key].push(p);
    return acc;
  }, {});

  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, minmax(0,1fr))', gap: 12, marginBottom: 24 }}>
        {[
          { label: 'Total tasks',  value: total,     color: '#0f172a' },
          { label: 'Completed',    value: done,      color: '#10b981' },
          { label: 'In progress',  value: inProg,    color: '#3b82f6' },
          { label: 'Blocked',      value: blocked,   color: '#ef4444' },
          { label: 'Overall',      value: `${pct}%`, color: '#0f172a' },
        ].map(m => (
          <div key={m.label} style={{ background: '#f8fafc', borderRadius: 8, padding: 14 }}>
            <div style={{ fontSize: 12, color: '#64748b', marginBottom: 4 }}>{m.label}</div>
            <div style={{ fontSize: 22, fontWeight: 500, color: m.color }}>{m.value}</div>
          </div>
        ))}
      </div>

      {Object.entries(grouped).map(([proj, ptasks]) => {
        const t = ptasks.length;
        const d = ptasks.filter(x => x.status === 'done').length;
        const p = t > 0 ? Math.round((d / t) * 100) : 0;
        const progColor = p === 100 ? '#10b981' : p > 50 ? '#3b82f6' : '#f59e0b';

        return (
          <div key={proj} style={{ background: '#fff', border: '0.5px solid #e2e8f0', borderRadius: 12, padding: 16, marginBottom: 14 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
              <span style={{ fontSize: 15, fontWeight: 500, color: '#0f172a' }}>{proj}</span>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 12, color: '#64748b' }}>{d}/{t} done</span>
                {p === 100 && (
                  <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 999, background: 'rgba(16,185,129,0.12)', color: '#10b981' }}>
                    Complete
                  </span>
                )}
              </div>
            </div>
            <div style={{ height: 6, background: '#f1f5f9', borderRadius: 999, overflow: 'hidden', marginBottom: 8 }}>
              <div style={{ width: `${p}%`, height: '100%', background: progColor, borderRadius: 999, transition: 'width 0.4s' }} />
            </div>
            <div style={{ display: 'flex', gap: 6, marginBottom: 10, flexWrap: 'wrap' }}>
              {STATUS_ORDER.filter(s => ptasks.filter(x => x.status === s).length > 0).map(s => {
                const count = ptasks.filter(x => x.status === s).length;
                const c = STATUS_CONFIG[s];
                return (
                  <span key={s} style={{ fontSize: 11, padding: '2px 7px', borderRadius: 999, background: c.bg, color: c.color }}>
                    {c.label}: {count}
                  </span>
                );
              })}
            </div>
            {ptasks.filter(t2 => t2.status !== 'done').map(t2 => (
              <div key={t2.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '5px 0', borderBottom: '0.5px solid #f1f5f9', fontSize: 12 }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 6, flex: 1 }}>
                  <PriorityDot priority={t2.priority} />{t2.task}
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ fontSize: 11, color: '#94a3b8' }}>{t2.owner || ''}</span>
                  <StatusPill status={t2.status} />
                </span>
              </div>
            ))}
          </div>
        );
      })}
    </div>
  );
}

// ─── Weekly view ──────────────────────────────────────────────────────────────

function WoWChart({ weeks, tasksByKey }) {
  const canvasRef = useRef(null);
  const chartRef  = useRef(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    if (chartRef.current) chartRef.current.destroy();

    const labels = weeks.map(w => fmtShort(w.monday));
    const totals = weeks.map(w => (tasksByKey[w.key] || []).length);
    const dones  = weeks.map(w => (tasksByKey[w.key] || []).filter(t => t.status === 'done').length);
    const last   = weeks.length - 1;

    chartRef.current = new Chart(canvasRef.current, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: 'Total tasks',
            data: totals,
            backgroundColor: weeks.map((_, i) => i === last ? '#93c5fd' : '#dbeafe'),
            borderColor:     weeks.map((_, i) => i === last ? '#3b82f6' : '#93c5fd'),
            borderWidth: 1, borderRadius: 4,
          },
          {
            label: 'Completed',
            data: dones,
            backgroundColor: weeks.map((_, i) => i === last ? '#34d399' : '#a7f3d0'),
            borderColor:     weeks.map((_, i) => i === last ? '#10b981' : '#6ee7b7'),
            borderWidth: 1, borderRadius: 4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              afterLabel: (ctx) => {
                if (ctx.datasetIndex === 1) {
                  const tot = totals[ctx.dataIndex];
                  return tot > 0 ? `${Math.round((ctx.raw / tot) * 100)}% completion rate` : '';
                }
              },
            },
          },
        },
        scales: {
          x: { grid: { display: false }, ticks: { font: { size: 11 }, color: '#94a3b8', autoSkip: false, maxRotation: 30 } },
          y: { beginAtZero: true, grid: { color: 'rgba(148,163,184,0.12)' }, ticks: { font: { size: 11 }, color: '#94a3b8', stepSize: 1 } },
        },
      },
    });

    return () => chartRef.current?.destroy();
  }, [weeks, tasksByKey]);

  return (
    <div style={{ position: 'relative', width: '100%', height: 220, marginBottom: 24 }}>
      <canvas ref={canvasRef} role="img" aria-label="Bar chart of weekly task completion" />
    </div>
  );
}

function WeeklyTaskItem({ task, isCurrent, onPush }) {
  const sc = STATUS_CONFIG[task.status] || STATUS_CONFIG.backlog;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 14px', borderBottom: '0.5px solid #f1f5f9' }}>
      <span style={{ width: 7, height: 7, borderRadius: '50%', background: sc.color, flexShrink: 0 }} />
      <span style={{ fontSize: 13, color: '#0f172a', flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} title={task.task}>
        {task.task}
      </span>
      <span style={{ fontSize: 11, color: '#94a3b8', flexShrink: 0 }}>{task.owner}</span>
      {isCurrent && task.status !== 'done'
        ? (
          <button onClick={() => onPush(task.id)}
            style={{ padding: '3px 9px', fontSize: 11, whiteSpace: 'nowrap', border: '0.5px solid #e2e8f0', borderRadius: 6, background: '#f8fafc', color: '#64748b', cursor: 'pointer' }}>
            Push →
          </button>
        )
        : <StatusPill status={task.status} />
      }
    </div>
  );
}

function WeekColumn({ tasks, monday, isCurrent, onPush }) {
  const [showDone, setShowDone] = useState(false);
  const doneTasks    = tasks.filter(t => t.status === 'done');
  const nonDoneTasks = tasks.filter(t => t.status !== 'done');
  const sortOrder    = ['review', 'in-progress', 'todo', 'blocked', 'backlog'];
  const sorted       = [...nonDoneTasks].sort((a, b) => sortOrder.indexOf(a.status) - sortOrder.indexOf(b.status));

  return (
    <div style={{ background: '#fff', border: '0.5px solid #e2e8f0', borderRadius: 12, overflow: 'hidden' }}>
      <div style={{ padding: '10px 14px', borderBottom: '0.5px solid #e2e8f0',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        background: isCurrent ? '#f0fdf4' : '#f8fafc' }}>
        <div>
          <div style={{ fontSize: 13, fontWeight: 500, color: '#0f172a' }}>{isCurrent ? 'Current week' : 'Previous week'}</div>
          <div style={{ fontSize: 11, color: '#64748b' }}>{weekRangeLabel(monday)}</div>
        </div>
        <span style={{ fontSize: 12, color: '#10b981', fontWeight: 500 }}>{doneTasks.length}/{tasks.length} done</span>
      </div>
      {sorted.length === 0 && doneTasks.length === 0 && (
        <div style={{ padding: 24, textAlign: 'center', fontSize: 13, color: '#94a3b8' }}>No tasks</div>
      )}
      {sorted.map(t => <WeeklyTaskItem key={t.id} task={t} isCurrent={isCurrent} onPush={onPush} />)}
      {showDone && doneTasks.map(t => <WeeklyTaskItem key={t.id} task={t} isCurrent={false} onPush={onPush} />)}
      {doneTasks.length > 0 && (
        <div onClick={() => setShowDone(s => !s)}
          style={{ padding: '8px 14px', cursor: 'pointer', fontSize: 12, color: '#94a3b8',
            background: '#f8fafc', borderTop: '0.5px solid #f1f5f9', textAlign: 'center' }}>
          {showDone ? `▲ Hide ${doneTasks.length} done` : `▼ Show ${doneTasks.length} done`}
        </div>
      )}
    </div>
  );
}

function WeeklyView({ tasks }) {
  const [viewOffset, setViewOffset] = useState(0);

  const toWeekTask = (t) => {
    const base = t.dueDate ? new Date(t.dueDate) : TODAY;
    const mon  = getMonday(isNaN(base.getTime()) ? TODAY : base);
    return { ...t, assignedWeek: mon, weekKey: isoWeekKey(mon) };
  };

  const [weekTasks, setWeekTasks] = useState(() => tasks.map(toWeekTask));

  useEffect(() => { setWeekTasks(tasks.map(toWeekTask)); }, [tasks]); // eslint-disable-line

  function getWeeks(count = 8) {
    return Array.from({ length: count }, (_, i) => {
      const mon = getMonday(addDays(TODAY, 7 * (i - count + 1 + viewOffset)));
      return { monday: mon, key: isoWeekKey(mon) };
    });
  }

  function pushToNextWeek(taskId) {
    setWeekTasks(prev => prev.map(t => {
      if (t.id !== taskId) return t;
      const nextMon = addDays(t.assignedWeek, 7);
      return { ...t, assignedWeek: new Date(nextMon), weekKey: isoWeekKey(nextMon) };
    }));
  }

  const weeks     = getWeeks();
  const currWeek  = weeks[weeks.length - 1];
  const prevWeek  = weeks[weeks.length - 2];

  const tasksByKey = weeks.reduce((acc, w) => {
    acc[w.key] = weekTasks.filter(t => t.weekKey === w.key);
    return acc;
  }, {});

  const currTasks = tasksByKey[currWeek.key] || [];
  const prevTasks = tasksByKey[prevWeek.key] || [];
  const currDone  = currTasks.filter(t => t.status === 'done').length;
  const prevDone  = prevTasks.filter(t => t.status === 'done').length;
  const currTotal = currTasks.length;
  const pct       = currTotal > 0 ? Math.round((currDone / currTotal) * 100) : 0;
  const carried   = currTasks.filter(t => t.status !== 'done' && t.status !== 'backlog').length;
  const delta     = currDone - prevDone;

  const navBtnStyle = { padding: '5px 12px', fontSize: 13, cursor: 'pointer', border: '0.5px solid #e2e8f0', borderRadius: 8, background: '#fff', color: '#0f172a' };

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
        <span style={{ fontSize: 14, fontWeight: 500, color: '#0f172a' }}>Week-on-week tracker</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button style={navBtnStyle} onClick={() => setViewOffset(v => v - 1)}>← Prev</button>
          <span style={{ fontSize: 13, color: '#64748b', minWidth: 168, textAlign: 'center' }}>{weekRangeLabel(currWeek.monday)}</span>
          <button style={navBtnStyle} onClick={() => setViewOffset(v => v + 1)}>Next →</button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0,1fr))', gap: 12, marginBottom: 20 }}>
        {[
          { label: 'Tasks this week', value: currTotal,  color: '#0f172a', showDelta: false },
          { label: 'Completed',       value: currDone,   color: '#10b981', showDelta: true  },
          { label: 'Completion rate', value: `${pct}%`,  color: '#0f172a', showDelta: false },
          { label: 'Carried forward', value: carried,    color: '#f59e0b', showDelta: false },
        ].map(m => (
          <div key={m.label} style={{ background: '#f8fafc', borderRadius: 8, padding: 14 }}>
            <div style={{ fontSize: 12, color: '#64748b', marginBottom: 4 }}>
              {m.label}
              {m.showDelta && (
                <span style={{ fontSize: 12, fontWeight: 500, marginLeft: 6, color: delta > 0 ? '#10b981' : delta < 0 ? '#ef4444' : '#94a3b8' }}>
                  {delta > 0 ? `+${delta}` : delta < 0 ? delta : '—'}
                </span>
              )}
            </div>
            <div style={{ fontSize: 22, fontWeight: 500, color: m.color }}>{m.value}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: 16, marginBottom: 8, fontSize: 12, color: '#64748b' }}>
        {[['#3b82f6', '#dbeafe', 'Total tasks'], ['#10b981', '#a7f3d0', 'Completed']].map(([border, bg, label]) => (
          <span key={label} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
            <span style={{ width: 10, height: 10, borderRadius: 2, background: bg, border: `1px solid ${border}` }} />
            {label}
          </span>
        ))}
        <span style={{ marginLeft: 'auto', fontSize: 12, color: '#94a3b8' }}>Current week highlighted</span>
      </div>

      <WoWChart weeks={weeks} tasksByKey={tasksByKey} />

      <p style={{ fontSize: 13, fontWeight: 500, color: '#64748b', marginBottom: 12 }}>
        {weekRangeLabel(currWeek.monday)} vs previous week
      </p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0,1fr))', gap: 16 }}>
        <WeekColumn tasks={prevTasks} monday={prevWeek.monday} isCurrent={false} onPush={pushToNextWeek} />
        <WeekColumn tasks={currTasks} monday={currWeek.monday} isCurrent={true}  onPush={pushToNextWeek} />
      </div>
    </div>
  );
}

// ─── Sprint banner ────────────────────────────────────────────────────────────

function SprintBanner({ sprints, currentSprint, selectedSprint, onSelect, onRollover, rolloverMsg }) {
  return (
    <div style={{
      background: '#fff', border: '0.5px solid #e2e8f0', borderRadius: 12,
      padding: '14px 18px', marginBottom: 18,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <span style={{ fontSize: 13, color: '#64748b' }}>Sprint</span>
        <select
          value={selectedSprint}
          onChange={e => onSelect(e.target.value === 'all' ? 'all' : parseInt(e.target.value))}
          style={{ padding: '5px 10px', fontSize: 13, borderRadius: 8, border: '0.5px solid #e2e8f0', background: '#f8fafc', color: '#0f172a', fontWeight: 500 }}
        >
          <option value="all">All sprints</option>
          {sprints.map(s => (
            <option key={s} value={s}>
              Sprint {s}{s === currentSprint ? ' (current)' : ''}
            </option>
          ))}
        </select>
        {selectedSprint !== 'all' && selectedSprint === currentSprint && (
          <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 999, background: 'rgba(59,130,246,0.1)', color: '#1d4ed8', fontWeight: 500 }}>
            Current sprint
          </span>
        )}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        {rolloverMsg && (
          <span style={{ fontSize: 12, color: '#10b981' }}>{rolloverMsg}</span>
        )}
        <button
          onClick={onRollover}
          style={{ ...btnBase, background: 'rgba(239,68,68,0.07)', color: '#dc2626', border: '0.5px solid rgba(239,68,68,0.2)', fontSize: 12 }}
          title="Move all incomplete tasks from the current sprint to the next sprint"
        >
          Roll over → Sprint {currentSprint + 1}
        </button>
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────

export default function ProjectPlanner() {
  const [projects,        setProjects]       = useState([]);
  const [view,            setView]           = useState('board');
  const [syncMsg,         setSyncMsg]        = useState('');
  const [syncOk,          setSyncOk]         = useState(true);
  const [sheetUrl,        setSheetUrl]       = useState('https://docs.google.com/spreadsheets/d/1cZ3iMZVdT6C9F7J3x5bgzPsn67LdxeRPO-R84dVRh_M/edit');
  const [sheetTab,        setSheetTab]       = useState('Sheet1');
  const [search,          setSearch]         = useState('');
  const [filterProject,   setFP]             = useState('');
  const [filterOwner,     setFO]             = useState('');
  const [filterPriority,  setFPri]           = useState('');
  const [selectedSprint,  setSelectedSprint] = useState('all');
  const [showNewTask,     setShowNewTask]     = useState(false);
  const [rolloverMsg,     setRolloverMsg]     = useState('');
  const [writeMsg,        setWriteMsg]        = useState('');

  // Derive sprint list from tasks
  const sprints       = [...new Set(projects.map(p => p.sprint || 1))].sort((a, b) => a - b);
  const currentSprint = sprints.length > 0 ? Math.max(...sprints) : 1;

  const loadData = async () => {
    const id = extractId(sheetUrl);
    if (!id) { setSyncMsg('Invalid URL'); setSyncOk(false); return; }
    setSyncMsg('Syncing…'); setSyncOk(true);
    try {
      const res  = await fetch(`https://opensheet.elk.sh/${id}/${sheetTab}`);
      if (!res.ok) throw new Error('Failed');
      const data = await res.json();
      if (!data?.length) throw new Error('No data');
      const headers = Object.keys(data[0]);
      const mapped  = data.map((r, i) => mapRow(headers.map(h => r[h]), headers, i));
      setProjects(mapped);
      setSyncMsg(`Synced ${mapped.length} tasks`); setSyncOk(true);
      // Default to current sprint
      const sprintNums = [...new Set(mapped.map(p => p.sprint || 1))].sort((a, b) => a - b);
      if (sprintNums.length > 0) setSelectedSprint(Math.max(...sprintNums));
    } catch {
      setProjects(SAMPLE_DATA);
      setSyncMsg('Could not load sheet — showing sample data'); setSyncOk(false);
      setSelectedSprint(currentSprint);
    }
  };

  useEffect(() => { loadData(); }, []); // eslint-disable-line

  // Auto-select current sprint when sprints load
  useEffect(() => {
    if (sprints.length > 0 && selectedSprint === 'all') {
      setSelectedSprint(currentSprint);
    }
  }, [sprints.length]); // eslint-disable-line

  const moveTask = (id, dir) => {
    setProjects(prev => prev.map(p => {
      if (p.id !== id) return p;
      const idx = STATUS_ORDER.indexOf(p.status);
      const ni  = Math.max(0, Math.min(STATUS_ORDER.length - 1, idx + dir));
      return { ...p, status: STATUS_ORDER[ni] };
    }));
  };

  // Roll over: move all non-done tasks in currentSprint → currentSprint + 1
  const handleRollover = () => {
    let count = 0;
    setProjects(prev => prev.map(p => {
      if ((p.sprint || 1) === currentSprint && p.status !== 'done') {
        count++;
        return { ...p, sprint: currentSprint + 1 };
      }
      return p;
    }));
    const nextSprint = currentSprint + 1;
    setRolloverMsg(`${count} task${count !== 1 ? 's' : ''} rolled to Sprint ${nextSprint}`);
    setSelectedSprint(nextSprint);
    setTimeout(() => setRolloverMsg(''), 4000);

    // Write back if Apps Script is configured
    if (APPS_SCRIPT_URL) {
      const sheetId = extractId(sheetUrl);
      projects.forEach(p => {
        if ((p.sprint || 1) === currentSprint && p.status !== 'done') {
          writeToSheet('update', sheetId, sheetTab, p.id, { sprint: nextSprint });
        }
      });
    }
  };

  // Add new task
  const handleAddTask = async (form) => {
    const newTask = {
      ...form,
      id: Date.now(),
      sprint: form.sprint || currentSprint,
    };
    setProjects(prev => [...prev, newTask]);

    // Write to sheet if configured
    if (APPS_SCRIPT_URL) {
      const sheetId = extractId(sheetUrl);
      const result  = await writeToSheet('append', sheetId, sheetTab, null, form);
      setWriteMsg(result.ok ? '✓ Saved to sheet' : '⚠ Saved locally only (sheet write failed)');
    } else {
      setWriteMsg('✓ Added locally — configure Apps Script URL to sync to sheet');
    }
    setTimeout(() => setWriteMsg(''), 4000);
  };

  // Sprint-filtered tasks
  const sprintFiltered = selectedSprint === 'all'
    ? projects
    : projects.filter(p => (p.sprint || 1) === selectedSprint);

  const filtered = sprintFiltered.filter(p =>
    (!search         || normalize(p.task).includes(normalize(search)) || normalize(p.description || '').includes(normalize(search)) || normalize(p.owner).includes(normalize(search))) &&
    (!filterProject  || p.project  === filterProject) &&
    (!filterOwner    || p.owner    === filterOwner) &&
    (!filterPriority || p.priority === filterPriority)
  );

  const projectOptions = [...new Set(projects.map(p => p.project).filter(Boolean))];
  const ownerOptions   = [...new Set(projects.map(p => p.owner).filter(Boolean))];

  const tabStyle = (v) => ({
    padding: '6px 14px', fontSize: 13, cursor: 'pointer',
    border:      view === v ? '0.5px solid #e2e8f0' : 'none',
    background:  view === v ? '#fff' : 'transparent',
    color:       view === v ? '#0f172a' : '#64748b',
    fontWeight:  view === v ? 500 : 400,
    borderRadius: 6,
  });

  const selectStyle = {
    padding: '6px 10px', fontSize: 13, borderRadius: 8,
    border: '0.5px solid #e2e8f0', background: '#fff', color: '#0f172a',
  };

  return (
    <div style={{ padding: 20, fontFamily: 'sans-serif', background: '#f8fafc', minHeight: '100vh' }}>

      {/* New task modal */}
      {showNewTask && (
        <NewTaskModal
          onClose={() => setShowNewTask(false)}
          onSave={handleAddTask}
          projectOptions={projectOptions}
          ownerOptions={ownerOptions}
          currentSprint={currentSprint}
        />
      )}

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ fontSize: 18, fontWeight: 500, color: '#0f172a' }}>Project Planner</span>
          {syncMsg && (
            <span style={{
              fontSize: 12, padding: '3px 10px', borderRadius: 8,
              background: syncOk ? 'rgba(16,185,129,0.12)' : 'rgba(239,68,68,0.12)',
              color:      syncOk ? '#10b981'               : '#ef4444',
            }}>
              {syncMsg}
            </span>
          )}
          {writeMsg && (
            <span style={{ fontSize: 12, padding: '3px 10px', borderRadius: 8, background: 'rgba(59,130,246,0.1)', color: '#1d4ed8' }}>
              {writeMsg}
            </span>
          )}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button
            onClick={() => setShowNewTask(true)}
            style={{ ...btnBase, background: '#0f172a', color: '#fff', border: 'none', fontWeight: 500 }}
          >
            + New task
          </button>
          <div style={{ display: 'flex', gap: 4, background: '#f1f5f9', padding: 4, borderRadius: 8 }}>
            {['board', 'list', 'summary', 'weekly'].map(v => (
              <button key={v} style={tabStyle(v)} onClick={() => setView(v)}>
                {v.charAt(0).toUpperCase() + v.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Sheet bar */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap', alignItems: 'center' }}>
        <input
          value={sheetUrl}
          onChange={e => setSheetUrl(e.target.value)}
          placeholder="Paste Google Sheets URL..."
          style={{ flex: 1, minWidth: 220, fontSize: 13, padding: '7px 12px', borderRadius: 8, border: '0.5px solid #e2e8f0', background: '#fff', color: '#0f172a' }}
        />
        <select value={sheetTab} onChange={e => setSheetTab(e.target.value)} style={selectStyle}>
          <option>Sheet1</option><option>Sheet2</option><option>Sheet3</option>
        </select>
        <button onClick={loadData} style={{ ...selectStyle, background: 'rgba(59,130,246,0.1)', color: '#1d4ed8', border: '0.5px solid rgba(59,130,246,0.3)', cursor: 'pointer' }}>
          Sync
        </button>
        {APPS_SCRIPT_URL
          ? <span style={{ fontSize: 12, color: '#10b981' }}>✓ Write-back enabled</span>
          : <span style={{ fontSize: 12, color: '#94a3b8' }}>Read-only — set APPS_SCRIPT_URL for write-back</span>
        }
      </div>

      {/* Sprint banner (hidden on weekly view) */}
      {view !== 'weekly' && (
        <SprintBanner
          sprints={sprints.length > 0 ? sprints : [1]}
          currentSprint={currentSprint}
          selectedSprint={selectedSprint}
          onSelect={setSelectedSprint}
          onRollover={handleRollover}
          rolloverMsg={rolloverMsg}
        />
      )}

      {/* Filter bar (hidden on weekly view) */}
      {view !== 'weekly' && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap', alignItems: 'center' }}>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search tasks..."
            style={{ ...selectStyle, width: 180 }}
          />
          <select value={filterProject} onChange={e => setFP(e.target.value)} style={selectStyle}>
            <option value="">All projects</option>
            {projectOptions.map(p => <option key={p}>{p}</option>)}
          </select>
          <select value={filterOwner} onChange={e => setFO(e.target.value)} style={selectStyle}>
            <option value="">All owners</option>
            {ownerOptions.map(o => <option key={o}>{o}</option>)}
          </select>
          <select value={filterPriority} onChange={e => setFPri(e.target.value)} style={selectStyle}>
            <option value="">All priorities</option>
            <option>high</option><option>medium</option><option>low</option>
          </select>
          <span style={{ fontSize: 12, color: '#94a3b8', marginLeft: 'auto' }}>
            {filtered.length} task{filtered.length !== 1 ? 's' : ''}
          </span>
        </div>
      )}

      {/* Views */}
      {view === 'board'   && <BoardView   tasks={filtered} onMove={moveTask} />}
      {view === 'list'    && <ListView    tasks={filtered} />}
      {view === 'summary' && <SummaryView tasks={filtered} />}
      {view === 'weekly'  && <WeeklyView  tasks={projects} />}
    </div>
  );
}
